<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cliente', function (Blueprint $table) {
            $table->id('cliente_id');
            $table->string('nome');
            $table->string('sobrenome');
            $table->string('cpf')->nullable()->unique();
            $table->string('telefone')->nullable()->unique();
            $table->string('email')->nullable()->unique();
            $table->date('data_nascimento');
            $table->string('senha');
            $table->boolean('is_admin')->default(false);
            $table->timestamp('criado')->useCurrent();
            $table->timestamp('atualizado')->useCurrent()->useCurrentOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cliente');
    }
};
